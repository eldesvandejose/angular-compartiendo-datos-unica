import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SociosFormComponent } from './socios-form/socios-form.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule
  ],
  declarations: [
    SociosFormComponent
  ],
  exports: [
    SociosFormComponent
  ]
})
export class MyFormModule { }
