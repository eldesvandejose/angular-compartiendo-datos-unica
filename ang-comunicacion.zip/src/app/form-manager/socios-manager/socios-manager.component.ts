import { Component, OnInit } from '@angular/core';
import { AcdUser } from '../../acd-classes/acd-user';

@Component({
  selector: 'acd-socios-manager',
  templateUrl: './socios-manager.component.html',
  styleUrls: ['./socios-manager.component.css']
})
export class SociosManagerComponent implements OnInit {
  User: AcdUser;
  UsersArray: AcdUser[] = [];
  registeredUsers = 0;

  constructor() {}

  ngOnInit() {}

  mostrar(evento) {
    this.User = evento;
    this.UsersArray.push(this.User);
    this.registeredUsers = this.UsersArray.length;
  }

  erase(user: AcdUser) {
    const index = this.UsersArray.indexOf(user);
    this.UsersArray.splice(index, 1);
    this.registeredUsers = this.UsersArray.length;
  }
}
