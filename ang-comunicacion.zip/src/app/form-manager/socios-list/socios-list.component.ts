import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { AcdUser } from '../../acd-classes/acd-user';

@Component({
  selector: 'acd-socios-list',
  templateUrl: './socios-list.component.html',
  styleUrls: ['./socios-list.component.css']
})
export class SociosListComponent implements OnInit {
  @Input() registeredUsers = 0;
  @Input() UsersArray: AcdUser[];

  @Output() eraseUser = new EventEmitter<AcdUser>();

  constructor() {}

  ngOnInit() {}

  deleteUser(deletedUser: AcdUser) {
    this.eraseUser.emit(deletedUser);
  }
}
